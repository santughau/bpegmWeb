<?php 
ob_start();
session_start();

require_once('inc/db.php');
include ("PHPExcel/IOFactory.php");
$objPHPExcel = PHPExcel_IOFactory::load('002.xlsx');
foreach($objPHPExcel->getWorksheetIterator() as $worksheet){
	$highestRow = $worksheet->getHighestRow();
	for($row=2; $row<=$highestRow; $row++){
		$gram = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(0,$row)->getValue());
		$name = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(2,$row)->getValue());
		$village = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(1,$row)->getValue());
		$gender = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(3,$row)->getValue());
        $age = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(4,$row)->getValue());
        $fromWhere = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(5,$row)->getValue());
        $date = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(6,$row)->getValue());
        $mobile = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(7,$row)->getValue());
        $checking = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(8,$row)->getValue());
        $shriChceckDate = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(9,$row)->getValue());
        $placeOfCheck = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(10,$row)->getValue());
        $stamp = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(11,$row)->getValue());
        $symption = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(12,$row)->getValue());
        $sList = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(13,$row)->getValue());
        $socDist = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(14,$row)->getValue());
        $policeStation = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(15,$row)->getValue());
        $uploadedBy = mysqli_real_escape_string($con, $worksheet->getCellByColumnAndRow(16,$row)->getValue());
		
		$sql = "INSERT INTO data(gram,name,village,gender,age,fromWhere,date,mobile,checking,shriChceckDate, placeOfCheck,stamp,symption,sList,socDist,policeStation,uploadedBy)VALUES('".$gram."','".$name."','".$village."','".$gender."',    '".$age."','".$fromWhere."','".$date."','".$mobile."','".$checking."','".$shriChceckDate."','".$placeOfCheck."','".$stamp."','".$symption."','".$sList."','".$socDist."','".$policeStation."','".$uploadedBy."')";
        
		mysqli_query($con,$sql);
	}
}

?>